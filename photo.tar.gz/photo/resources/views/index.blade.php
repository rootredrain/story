<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
		<script src="static/javascript/library/jquery.min.js"></script>
		<script src="static/dist/semantic.min.js"></script>
		<link rel="stylesheet" type="text/css" class="ui" href="static/dist/semantic.min.css">
	</head>
	<body>
		<div class="ui container header">
			<div class="ui relaxed grid">
				<div class="column">
					<div class="ui inverted menu">
						<div class="item">
							<img src="static/images/logo.png">
						</div>
						<a class="active item" href="/">首頁 </a>
						<a class="item" href="/wall">故事牆 </a>
					</div>
				</div>
			</div>
		</div>
		<div class="ui two column centered middle aligned very relaxed stackable grid doubling container divided">
			<div class="column">
				<div class="ui centered card">
				  <div class="image">
				    <img src="static/images/steve.jpg">
				  </div>
				  <div class="content">
				    <a class="header">史蒂夫·賈伯斯</a>
				    <div class="description">史蒂夫·賈伯斯是一個虛構人物，設計上類似於讀者所熟悉的某個人。</div>
				  </div>
				</div>
			</div>
			<div class="six wide column">
				<div class="ui attached message">
				  <div class="header">
				  	歡迎來到我們的網站！
				  </div>
				  <p>告訴我們你的故事</p>
				</div>
				<form class="ui form attached fluid segment" method="post" action="/" enctype="multipart/form-data">
					<div class="required field">
						<label>你的名字</label>
						<div class="ui left icon input">
							<input type="text" name="name" placeholder="人物名">
							<i class="user icon"></i>
						</div>
					</div>
					<div class="required field">
					    <label>你的故事</label>
					    <textarea rows="2" name="story" placeholder="你的故事"></textarea>
					</div>
					<div class="ui left icon field">
					    <label for="file" class="ui icon button">
					        <i class="file icon"></i>
					        選擇頭像ZIP壓縮檔案
					    </label>
					    <input type="file" id="file" name="zip" style="display:none">
					</div>
					
					<div class="two ui buttons">
						<div class="ui blue submit button">上傳</div>
						<div class="or"></div>
						<div class="ui clear button">清空</div>
					</div>
					<div class="ui error message"></div>
				</div>
			</div>
		</div>
		<script>
			$('.ui.form')
				.form({
			    	fields: {
			      		name: {
			        		identifier  : 'name',
			        		rules: [{
			            		type   : 'empty',
			            		prompt : '名字不能為空'
			          		}]
			      		},
			      		story: {
			      			identifier : 'story',
			      			rules: [{
			      				type   : 'empty',
			      				prompt : '故事不能為空'
			      			}]
			      		},
			      		zip: {
			      			identifier : 'zip',
			      			rules: [{
			      				type   : 'empty',
			      				prompt : '請選取壓縮檔案'
			      			}]
			      		}
			    	}
			  	});
		</script>
	</body>
</html>
