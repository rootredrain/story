<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
		<script src="static/javascript/library/jquery.min.js"></script>
		<script src="static/dist/semantic.min.js"></script>
		<link rel="stylesheet" type="text/css" class="ui" href="static/dist/semantic.min.css">
	</head>
	<body>
		<div class="ui container header">
			<div class="ui relaxed grid">
				<div class="column">
					<div class="ui inverted menu">
						<div class="item">
							<img src="static/images/logo.png">
						</div>
						<a class="item" href="/">首頁 </a>
						<a class="active item" href="/wall">故事牆 </a>
					</div>
				</div>
			</div>
		</div>
		<div class="ui four column middle aligned very relaxed stackable grid doubling container">
			@foreach($users as $user)
				<div class="column">
					<div class="ui card">
						<div class="image">
						  <img src="{{ $user->avator }}">
						</div>
						<div class="content">
						  <a class="header">{{ $user->name }}</a>
						  <div class="description">{{ $user->story }}</div>
						</div>
					</div>
				</div>
			@endforeach
		</div>
	</body>
</html>
